var resources = function (page, meta) {
    return {
        js: [],
        css: ['error.css']
    };
};