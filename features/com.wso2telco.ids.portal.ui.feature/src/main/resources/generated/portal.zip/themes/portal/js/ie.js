if (!window.console)
	console = {
		log : function(msg) {
			//alert(msg)
		}
	};
	
