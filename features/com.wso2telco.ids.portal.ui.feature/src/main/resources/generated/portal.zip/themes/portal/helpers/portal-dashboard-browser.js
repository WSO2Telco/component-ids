var resources = function (page, meta) {
    return {
        js: ['portal-dashboard-browser.js', 'jquery-ui-1.10.1.custom.min.js','jquery-ui-1.9.2.custom.min.js', 'elfinder.full.js', 'jquery.nicescroll.min.js' , 'jquery.tokeninput.js', 'jquery.validate.js'],
        css: ['elfinderTheme.css', 'elfinder.min.css' , 'theme.css', 'portal-dashboard.css', 'token-input.css' , 'token-input-facebook.css'],
        code: []
    };
};