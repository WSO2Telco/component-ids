var resources = function (page, meta) {
    return {
        js: ['portal-gadgets-js.jag','shindig.js', 'UESContainer.js', 'jshashtable-2.1_src.js',
            'jquery.numberformatter-1.2.3.js', 'tmpl.js', 'jquery.dependClass-0.1.js', 'draggable-0.1.js',
            'jquery.slider.js', 'jquery.scrollorama.js', 'portal-homepage.js', 'intro.js',
            'jquery.validate.js'],
        css: ['jslider.css', 'jslider.round.plastic.css', 'portal-homepage.css'],
        code: []
    };
};