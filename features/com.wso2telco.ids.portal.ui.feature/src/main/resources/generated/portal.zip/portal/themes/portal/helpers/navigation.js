var resources = function (page, meta) {
    return {
        js: ['navigation.js'],
        css: ['navigation.css']
    };
};