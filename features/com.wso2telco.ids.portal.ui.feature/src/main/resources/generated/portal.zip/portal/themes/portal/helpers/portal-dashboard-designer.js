var resources = function (page, meta) {
    return {
        template: 'portal-dashboard-designer.hbs',
        js: ['portal-gadgets-js.jag','shindig.js', 'UESContainer.js', 'jquery-ui-1.10.1.custom.min.js', 'jquery.gridster.with-extras.min.js', 'portal-dashboard-designer.js', 'alert.js'],
        css: ['jquery.gridster.min.css', 'portal-dashboard-designer.css'],
        code: []
    };
};
